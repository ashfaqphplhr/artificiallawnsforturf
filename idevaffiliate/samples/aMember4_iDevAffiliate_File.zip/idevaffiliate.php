<?php

class Am_Plugin_Idevaffiliate extends Am_Plugin
{
    const PLUGIN_STATUS = self::STATUS_BETA;
    const PLUGIN_REVISION = '@@VERSION@@';

    const PROFILE_NUM = '72198'; //@todo profile number should be supplied by iDevAffiliate team

    public function isConfigured()
    {
        return $this->getDi()->config->get('idevaffiliate_url');
    }

    function onSetupForms(Am_Event_SetupForms $event)
    {
        $form = new Am_Form_Setup('idevaffiliate');
        $form->setLabel('iDevAffiliate');
        $form->addText('idevaffiliate_url', array('size' => 50))
            ->setLabel(array("iDevAffiliate URL", "Url to iDevAffiliate installation without trailing slash"));
        $event->addForm($form);
    }

    function onInvoiceCalculate(Am_Event $event)
    {
        $invoice = $event->getInvoice();
        $invoice->data()->set('ip_address', $_SERVER['REMOTE_ADDR']);
    }

    function onPaymentAfterInsert(Am_Event_PaymentAfterInsert $event)
    {
        $payment = $event->getPayment();
        $invoice = $this->getDi()->invoiceTable->load($payment->invoice_id);
        try
        {
            $req = new Am_HttpRequest($this->getDi()->config->get('idevaffiliate_url') . '/sale.php?' .
                    http_build_query(array(
                        'profile' => self::PROFILE_NUM,
                        'idev_saleamt' => sprintf("%.2f", $payment->amount),
                        'idev_ordernum' => $payment->receipt_id,
                        'ip_address' => $invoice->data()->get('ip_address')
                    ))
            );
            $response = $req->send();
        }
        catch (Exception $e)
        {
            $this->getDi()->errorLogTable->logException($e);
        }
    }

}